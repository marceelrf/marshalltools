library(RcppFaddeeva)
library(testthat)

test_check("RcppFaddeeva")
