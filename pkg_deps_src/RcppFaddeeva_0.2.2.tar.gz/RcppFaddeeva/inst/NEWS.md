
# RcppFaddeeva 0.2.2 (28/05/2022)

* Update of maintainer's email address

# RcppFaddeeva 0.2.1 (09/2016)

INTERNAL CHANGES

* tests with testthat moved to correct location

# RcppFaddeeva 0.2.0 (13/06/2016)

* C++ API, contributed by Dennis Feehan

# RcppFaddeeva 0.1.1 (1/07/2015)

* Switch vignette engine to `rmarkdown`
* explicitly import `dnorm` from `stats`

# RcppFaddeeva 0.1.0 (9/06/2015)

* Initial version
